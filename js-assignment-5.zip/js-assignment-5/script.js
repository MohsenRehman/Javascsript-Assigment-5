// Employee Login System

        let isPasswordCorrect = true;
        if (isPasswordCorrect === true){
            console.log('Login Successful');
        }else{
            console.log('Password Inccorect');
        }

// Online Order Approval

        let isPaymentDone = true;
        if(isPasswordCorrect===true){
            console.log('Approve the order');   
        }else{
            console.log('Reject the order');
        }

// Student Result System

        let marks = 37;
        if(marks >= 50){
            console.log('Pass');
        }else{
            console.log('Fail');
        }
// Office Attendance Check

        let isOnTime=true;
        if(isOnTime===true){
            console.log("They arrived on time");
        }else{
            console.log("Late / Absent");
        }
// Discount Eligibility

        let isPremiumUser = true;

        if (isPremiumUser) {
            console.log("Discount Applied");
        } else {
            console.log("No Discount Available");
        }
// Multiple Conditions (else if)

        let performanceScore = 90;
        if(performanceScore >= 90){
            console.log('Excellent');
        }else if(performanceScore >= 70 ){
            console.log('Good');
        }else if (performanceScore >= 50){
            console.log("Average");
        }else {
            console.log("Poor");
        }
